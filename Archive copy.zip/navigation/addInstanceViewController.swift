//
//  addInstanceViewController.swift
//  navigation
//
//  Created by labuser on 10/28/17.
//  Copyright © 2017 bb. All rights reserved.
//

import Foundation
import UIKit

class addInstanceViewController: UIViewController {
    
    
    @IBOutlet weak var addInstance2: UIButton!
    
    @IBOutlet weak var input2: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}
